# Entailment Bank Evaluation

This evaluation code is part of the entailment bank repository available at:

[https://github.com/allenai/entailment_bank](https://github.com/allenai/entailment_bank)

Small changes made to support further metrics and small improvements in "task-3" evaluation.